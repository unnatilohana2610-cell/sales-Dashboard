import React from 'react';

export const KPICard = ({ title, value }: { title: string; value: any }) => (
  <div className="kpi">
    <div className="kpi-title">{title}</div>
    <div className="kpi-value">{String(value)}</div>
  </div>
);
