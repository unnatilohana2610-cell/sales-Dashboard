import React from 'react';

export const Filters = ({ regions, products, region, setRegion, product, setProduct, startDate, setStartDate, endDate, setEndDate }:
  any) => {
  return (
    <div className="filters">
      <select value={region} onChange={e => setRegion(e.target.value)}>
        <option value=''>All Regions</option>
        {regions.map((r: string) => <option key={r} value={r}>{r}</option>)}
      </select>

      <select value={product} onChange={e => setProduct(e.target.value)}>
        <option value=''>All Products</option>
        {products.map((p: string) => <option key={p} value={p}>{p}</option>)}
      </select>

      <label>
        Start
        <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
      </label>

      <label>
        End
        <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
      </label>

      <button onClick={() => { setRegion(''); setProduct(''); setStartDate(''); setEndDate(''); }}>Clear</button>
    </div>
  );
};
