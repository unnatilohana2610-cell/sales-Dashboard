import { useEffect, useState } from 'react';
import axios from 'axios';

export type Sale = {
  sale_id: string;
  date: string;
  region: string;
  product: string;
  quantity: number;
  unit_price: number;
  total_price: number;
};

const API_URL = 'https://68d424b8214be68f8c6887f1.mockapi.io/api/eureka/tech/task/sales';

export function useSalesData() {
  const [sales, setSales] = useState<Sale[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<any>(null);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const res = await axios.get(API_URL);
        const data = (res.data ?? []).map((r: any) => ({
          ...r,
          date: r.date,
          quantity: Number(r.quantity),
          unit_price: Number(r.unit_price),
          total_price: Number(r.total_price)
        }));
        if (mounted) setSales(data);
      } catch (err) {
        if (mounted) setError(err);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, []);

  return { sales, loading, error };
}
