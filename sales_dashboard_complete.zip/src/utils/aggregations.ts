import { format } from 'date-fns';
import type { Sale } from '../hooks/useSalesData';

export const totalRevenue = (sales: Sale[]) =>
  sales.reduce((acc, s) => acc + Number(s.total_price), 0);

export const salesByMonth = (sales: Sale[]) => {
  const map: Record<string, number> = {};
  sales.forEach(s => {
    let date = new Date(s.date);
    if (isNaN(date.getTime())) date = new Date();
    const key = format(date, 'yyyy-MM');
    map[key] = (map[key] || 0) + Number(s.total_price);
  });
  return Object.entries(map)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([month, value]) => ({ month, value }));
};

export const salesByRegion = (sales: Sale[]) => {
  const map: Record<string, number> = {};
  sales.forEach(s => map[s.region] = (map[s.region] || 0) + Number(s.total_price));
  return Object.entries(map).map(([region, value]) => ({ region, value }));
};

export const topProducts = (sales: Sale[], topN = 5, by: 'quantity' | 'revenue' = 'quantity') => {
  const map: Record<string, { quantity: number; revenue: number }> = {};
  sales.forEach(s => {
    if (!map[s.product]) map[s.product] = { quantity: 0, revenue: 0 };
    map[s.product].quantity += Number(s.quantity);
    map[s.product].revenue += Number(s.total_price);
  });
  const arr = Object.entries(map).map(([product, v]) => ({
    product,
    quantity: v.quantity,
    revenue: v.revenue
  }));
  return arr.sort((a,b) => (by==='quantity' ? b.quantity - a.quantity : b.revenue - a.revenue)).slice(0, topN);
};
